'use strict';

const restify = require('restify');

const port = process.env.PORT;

var server = restify.createServer();
server.pre(restify.pre.sanitizePath());
server.get('/', function (req, res, next) {
  res.send({
    echo: 'hello!'
  });
  next();
});


server.listen(port, function () {
  console.log('%s listening at %s', server.name, server.url);
});
